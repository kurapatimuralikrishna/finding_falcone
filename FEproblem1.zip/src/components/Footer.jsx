import React from "react";

const Footer = () => {
  return (
    <footer className="footer">
      <p>GeekTrust Coding Problem</p>
    </footer>
  );
};

export default Footer;
