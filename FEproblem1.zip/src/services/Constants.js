export const REQUIRED_PLANS = 4;
export const PLANETS_API = "https://findfalcone.herokuapp.com/planets";
export const VEHICLES_API = "https://findfalcone.herokuapp.com/vehicles";
export const TOKEN_API = "https://findfalcone.herokuapp.com/token";
export const FIND_FALCONE = "https://findfalcone.herokuapp.com/find";