#### To Run Application

**First, Install all the packages:**

```sh
$ npm install
```

**To Run Application**

```sh
$ npm start
```
